angular.module('UserControllers',[]).config(
    function () {
        console.log("In UserControllers config");
    }
);